using System;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SOLITUDE.Application.Persistence;
using SOLITUDE.Items;
namespace SOLITUDE.SaveLoad
{
    public sealed class SaveJsonCodec : ISnapshotCodec
    {
        private readonly IItemCatalog catalog;
        public SaveJsonCodec(IItemCatalog catalog) => this.catalog = catalog;
        private static JToken Required(JObject obj, string field, JTokenType type)
        {
            var token = obj[field];
            if (token == null || token.Type != type) throw new SaveCandidateException("Missing or invalid " + field);
            return token;
        }
        private static JObject OptionalObject(JObject obj, string field)
        {
            var token = obj[field];
            if (token == null || (token.Type != JTokenType.Null && token.Type != JTokenType.Object))
                throw new SaveCandidateException("Missing or invalid " + field);
            return token.Type == JTokenType.Null ? null : (JObject)token;
        }
        private static void Number(JObject obj, string field)
        {
            var token = obj[field];
            if (token == null || (token.Type != JTokenType.Integer && token.Type != JTokenType.Float))
                throw new SaveCandidateException("Missing or invalid " + field);
            double value = token.Value<double>();
            if (double.IsNaN(value) || double.IsInfinity(value)) throw new SaveCandidateException("Invalid " + field);
        }
        private static void Keys(JObject obj, string field)
        {
            foreach (var key in (JArray)Required(obj, field, JTokenType.Array))
                if (key.Type != JTokenType.String) throw new SaveCandidateException("Invalid " + field);
        }
        private static JObject Record(JToken token)
        {
            if (!(token is JObject record)) throw new SaveCandidateException("Invalid saved world record.");
            Required(record, "id", JTokenType.String);
            return record;
        }
        private static void Lifecycle(JObject obj)
        {
            var survivor = OptionalObject(obj, "survivor");
            if (survivor != null)
            {
                Required(survivor, "id", JTokenType.String); Required(survivor, "status", JTokenType.Integer);
                Required(survivor, "scenePath", JTokenType.String);
                foreach (var field in new[] { "x", "y", "z", "recoveryDelayRemaining" }) Number(survivor, field);
                foreach (var field in new[] { "health", "oxygen", "hunger" })
                {
                    var vital = (JObject)Required(survivor, field, JTokenType.Object);
                    Number(vital, "current"); Number(vital, "max");
                }
            }
            var expedition = OptionalObject(obj, "expedition");
            if (expedition != null)
            {
                Required(expedition, "id", JTokenType.String);
                Keys(expedition, "defeatedEncounterIds"); Keys(expedition, "collectedSupplySourceIds");
            }
            var ship = (JObject)Required(obj, "ship", JTokenType.Object);
            foreach (var token in (JArray)Required(ship, "repairs", JTokenType.Array))
            {
                var record = Record(token); Required(record, "installed", JTokenType.Boolean);
                Required(record, "running", JTokenType.Boolean); Number(record, "recoverySeconds");
            }
            foreach (var token in (JArray)Required(ship, "doors", JTokenType.Array))
            {
                var record = Record(token);
                foreach (var field in new[] { "powered", "unlocked", "open" }) Required(record, field, JTokenType.Boolean);
            }
            foreach (var token in (JArray)Required(ship, "criticalSources", JTokenType.Array))
            {
                var record = Record(token); Required(record, "objectiveId", JTokenType.String);
                Required(record, "available", JTokenType.Boolean);
            }
            Keys(ship, "permanentDiscoveryIds");
            var pending = OptionalObject(obj, "pendingDeath");
            if (pending != null)
            {
                foreach (var field in new[] { "id", "departingSurvivorId", "successorId", "departingExpeditionId", "expeditionId" })
                    Required(pending, field, JTokenType.String);
                Required(pending, "stage", JTokenType.Integer);
            }
        }
        public SaveGameData Decode(string json)
        {
            try
            {
                using var reader = new JsonTextReader(new StringReader(json)) { DateParseHandling = DateParseHandling.None };
                var obj = JObject.Load(reader, new JsonLoadSettings { DuplicatePropertyNameHandling = DuplicatePropertyNameHandling.Error });
                if (reader.Read()) throw new SaveCandidateException("Trailing save content.");
                int version = Required(obj, "version", JTokenType.Integer).Value<int>();
                if (version < 1 || version > SaveGameData.CurrentVersion) throw new SaveCandidateException("Unsupported save version.", true);
                Required(obj, "worldSeed", JTokenType.Integer).Value<int>();
                var records = (JArray)Required(obj, "containers", JTokenType.Array);
                foreach (var entry in records)
                {
                    if (!(entry is JObject record)) throw new SaveCandidateException("Invalid container record.");
                    Required(record, "saveableId", JTokenType.String);
                    var state = (JObject)Required(record, "state", JTokenType.Object);
                    foreach (var item in (JArray)Required(state, "slots", JTokenType.Array))
                    {
                        if (!(item is JObject slot)) throw new SaveCandidateException("Invalid slot.");
                        Required(slot, "index", JTokenType.Integer).Value<int>();
                        Required(slot, "quantity", JTokenType.Integer).Value<int>();
                        var id = Required(slot, "itemId", JTokenType.String).Value<string>();
                        if (!catalog.TryGet(id, out _)) throw new SaveCandidateException("Saved item is not in the current catalog: " + id, true);
                    }
                }
                if (version >= 2) Keys(obj, "collectedPickupIds");
                if (version >= 3) Lifecycle(obj);
                var data = obj.ToObject<SaveGameData>();
                return new ContainerSaveSession(data, catalog).Capture();
            }
            catch (SaveCandidateException) { throw; }
            catch (Exception error) when (error is JsonException || error is InvalidDataException || error is OverflowException || error is ArgumentException || error is FormatException)
            { throw new SaveCandidateException("Invalid save snapshot: " + error.Message); }
        }
        public string Encode(SaveGameData data) => JsonConvert.SerializeObject(data, Formatting.Indented);
    }
}
