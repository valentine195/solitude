using System;
using System.Collections.Generic;
using UnityEngine;
namespace SOLITUDE.Npcs.Sec0
{
    // Local four-neighbour routing keeps the rover out of walls and avoids
    // diagonal corner cutting. A solid-body cast still guards every actual move.
    internal sealed class Sec0Navigator
    {
        private const float Cell=.5f;
        private static readonly Vector2Int[] Neighbours={Vector2Int.right,Vector2Int.up,Vector2Int.left,Vector2Int.down};
        private readonly Func<Vector2,Vector2,bool> clear;
        private readonly List<Vector2> path=new();
        private Vector2 goal;
        private float refresh;
        public Sec0Navigator(Func<Vector2,Vector2,bool> clear)=>this.clear=clear;
        public void Reset() { path.Clear();refresh=0; }
        public Vector2 Next(Vector2 position,Vector2 destination,float elapsed)
        {
            if(clear(position,destination)) { path.Clear();return destination; }
            refresh-=elapsed;
            if(refresh<=0 || Vector2.Distance(goal,destination)>.4f) Build(position,destination);
            while(path.Count>0 && Vector2.Distance(position,path[0])<.12f) path.RemoveAt(0);
            if(path.Count==0) return position;
            if(!clear(position,path[0])) { refresh=0;return position; }
            return path[0];
        }
        private void Build(Vector2 position,Vector2 destination)
        {
            goal=destination;refresh=.5f;path.Clear();
            // Use the exact current position as the grid origin, so the first
            // edge is safe even when the actor is between world grid centres.
            var start=Vector2Int.zero;var frontier=new Queue<Vector2Int>();frontier.Enqueue(start);
            var parents=new Dictionary<Vector2Int,Vector2Int>{{start,start}};
            var found=start;bool success=false;
            while(frontier.Count>0 && parents.Count<900)
            {
                var current=frontier.Dequeue();Vector2 world=position+(Vector2)current*Cell;
                if(Vector2.Distance(world,destination)<Cell && clear(world,destination)) {found=current;success=true;break;}
                foreach(var offset in Neighbours)
                {
                    var next=current+offset;
                    if(Mathf.Abs(next.x)>16 || Mathf.Abs(next.y)>16 || parents.ContainsKey(next)) continue;
                    if(!clear(world,position+(Vector2)next*Cell)) continue;
                    parents.Add(next,current);frontier.Enqueue(next);
                }
            }
            if(!success) return;
            while(found!=start) {path.Add(position+(Vector2)found*Cell);found=parents[found];}
            path.Reverse();path.Add(destination);
        }
    }
}
